import { motion } from "framer-motion";
import { useState, useRef } from "react";
import { Upload, FileVideo, X, AlertTriangle } from "lucide-react";

const UploadSection = () => {
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (f: File) => {
    if (f.type.startsWith("video/")) {
      setFile(f);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  };

  return (
    <section id="upload" className="py-24 relative">
      <div className="container mx-auto px-6 max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-xs font-medium tracking-widest uppercase text-primary">Try It Out</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold mt-3">
            Upload <span className="gradient-text">Your Video</span>
          </h2>
          <p className="text-sm text-muted-foreground mt-3">
            Select a video file to analyze for potential deepfake manipulation.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
          className={`glass rounded-2xl p-12 text-center cursor-pointer transition-all duration-300 ${
            dragging ? "neon-glow border-primary/50" : "hover:neon-glow"
          }`}
        >
          <input
            ref={inputRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />

          {!file ? (
            <>
              <Upload className="w-12 h-12 text-primary mx-auto mb-4 animate-float" />
              <p className="text-foreground font-medium mb-1">
                Drag & drop your video here
              </p>
              <p className="text-sm text-muted-foreground">
                or click to browse · MP4, AVI, MOV supported
              </p>
            </>
          ) : (
            <div className="flex items-center justify-center gap-4">
              <FileVideo className="w-8 h-8 text-primary" />
              <div className="text-left">
                <p className="text-sm font-medium text-foreground">{file.name}</p>
                <p className="text-xs text-muted-foreground">
                  {(file.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
              <button
                onClick={(e) => { e.stopPropagation(); setFile(null); }}
                className="p-1 rounded-full hover:bg-secondary transition-colors"
                aria-label="Remove file"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          )}
        </motion.div>

        {file && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-6 text-center">
            <button className="gradient-primary px-8 py-3 rounded-lg font-semibold text-primary-foreground text-sm neon-glow hover:opacity-90 transition-opacity">
              Analyze Now
            </button>
            <div className="flex items-center justify-center gap-2 mt-4 text-xs text-muted-foreground">
              <AlertTriangle className="w-3 h-3" />
              <span>Frontend demo only — no actual processing occurs.</span>
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default UploadSection;
