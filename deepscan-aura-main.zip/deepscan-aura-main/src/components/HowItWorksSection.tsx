import { motion } from "framer-motion";
import { Layers, ScanEye, Activity, CheckCircle } from "lucide-react";

const steps = [
  {
    icon: Layers,
    step: "01",
    title: "Frame Extraction",
    description: "Video is broken into individual frames for detailed per-frame analysis.",
  },
  {
    icon: ScanEye,
    step: "02",
    title: "CNN Feature Detection",
    description: "Convolutional Neural Networks extract spatial features like facial artifacts and texture anomalies.",
  },
  {
    icon: Activity,
    step: "03",
    title: "LSTM Temporal Analysis",
    description: "Long Short-Term Memory networks analyze temporal patterns across frames for inconsistencies.",
  },
  {
    icon: CheckCircle,
    step: "04",
    title: "Final Prediction",
    description: "Combined analysis produces a confidence score indicating whether the video is real or manipulated.",
  },
];

const HowItWorksSection = () => {
  return (
    <section id="how-it-works" className="py-24 relative">
      <div className="absolute inset-0 grid-bg opacity-10" />
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs font-medium tracking-widest uppercase text-primary">Process Flow</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold mt-3">
            How <span className="gradient-text">It Works</span>
          </h2>
        </motion.div>

        <div className="relative">
          {/* Connecting line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent -translate-y-1/2" />

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.15 }}
                viewport={{ once: true }}
                className="glass rounded-2xl p-8 text-center relative group hover:neon-glow-purple transition-all duration-300 hover:-translate-y-1"
              >
                <span className="font-display text-5xl font-black text-muted/30 absolute top-4 right-4">
                  {item.step}
                </span>
                <div className="w-14 h-14 rounded-full gradient-primary flex items-center justify-center mx-auto mb-5">
                  <item.icon className="w-7 h-7 text-primary-foreground" />
                </div>
                <h3 className="font-display text-base font-semibold mb-3">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
