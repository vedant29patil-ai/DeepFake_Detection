import { motion } from "framer-motion";
import { Mail, MapPin, Github, Linkedin, Twitter } from "lucide-react";

const Footer = () => {
  return (
    <footer id="contact" className="py-16 border-t border-border relative">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <h3 className="font-display text-xl font-bold mb-3">
              <span className="gradient-text">DEEP</span>GUARD
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Advanced AI-powered deepfake detection using CNN and LSTM neural networks.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-sm font-semibold mb-4 uppercase tracking-wider">Contact</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-primary" />
                contact@deepguard.ai
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary" />
                Research Lab, AI Campus
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-display text-sm font-semibold mb-4 uppercase tracking-wider">Follow Us</h4>
            <div className="flex gap-3">
              {[Github, Linkedin, Twitter].map((Icon, i) => (
                <motion.a
                  key={i}
                  href="#"
                  whileHover={{ scale: 1.1 }}
                  className="w-10 h-10 glass rounded-lg flex items-center justify-center hover:neon-glow transition-shadow"
                >
                  <Icon className="w-4 h-4 text-muted-foreground" />
                </motion.a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border text-center text-xs text-muted-foreground">
          © 2026 DeepGuard. Built for academic research purposes.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
