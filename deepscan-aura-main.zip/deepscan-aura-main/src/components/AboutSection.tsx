import { motion } from "framer-motion";
import { Brain, Eye, ShieldCheck } from "lucide-react";

const AboutSection = () => {
  const features = [
    {
      icon: Eye,
      title: "What Are Deepfakes?",
      description:
        "AI-generated synthetic media that manipulate faces and voices in videos, making them appear authentic and potentially harmful.",
    },
    {
      icon: Brain,
      title: "Why Detection Matters",
      description:
        "Deepfakes threaten misinformation, identity theft, and public trust. Early detection is critical for cybersecurity.",
    },
    {
      icon: ShieldCheck,
      title: "Our AI Approach",
      description:
        "We combine CNN for spatial feature extraction with LSTM for temporal analysis, catching inconsistencies humans can't see.",
    },
  ];

  return (
    <section id="about" className="py-24 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs font-medium tracking-widest uppercase text-primary">About the System</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold mt-3">
            Understanding <span className="gradient-text">Deepfake Detection</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.15 }}
              viewport={{ once: true }}
              className="glass rounded-2xl p-8 group hover:neon-glow transition-all duration-300 hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center mb-5">
                <feature.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="font-display text-lg font-semibold mb-3">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
